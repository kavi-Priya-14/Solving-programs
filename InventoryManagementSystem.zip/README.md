# Inventory Management System

A simple Java-based Inventory Management System using a HashMap to store and manage products.

## Features

- Add products to inventory
- Update product details
- Delete products
- Display all products

## Technologies

- Java
- HashMap for O(1) access and updates

## Run Instructions

1. Clone the repository
2. Compile and run the code:

```bash
javac -d . src/com/inventory/*.java
java com.inventory.InventoryManager
```

## Sample Output

```
P002 | Mouse | Qty: 45 | Price: 24.99
```

## Explanation

- A **Laptop** (`P001`) and **Mouse** (`P002`) are added.
- The **Mouse** is updated.
- The **Laptop** is deleted.
- Final inventory contains only the updated **Mouse**.
